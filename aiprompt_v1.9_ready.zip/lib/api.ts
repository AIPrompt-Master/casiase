export async function fetchTools() {
  return [
    { id: 1, name: '책 요약기', description: '책 내용을 요약해주는 툴' },
    { id: 2, name: '이미지 생성기', description: '프롬프트로 이미지를 생성' }
  ];
}
