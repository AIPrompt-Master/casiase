interface ToolCardProps {
  title: string;
  description: string;
}

export default function ToolCard({ title, description }: ToolCardProps) {
  return (
    <div className="border p-4 rounded">
      <h2>{title}</h2>
      <p>{description}</p>
    </div>
  );
}
