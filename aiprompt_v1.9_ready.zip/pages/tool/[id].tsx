import { useRouter } from 'next/router';

export default function ToolDetail() {
  const router = useRouter();
  const { id } = router.query;

  return <div>툴 상세 페이지 - ID: {id}</div>;
}
