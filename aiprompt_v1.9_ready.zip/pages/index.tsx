import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>AiPrompt</title>
      </Head>
      <main>
        <h1>AiPrompt 홈</h1>
        <p>환영합니다! 여기는 툴 마켓입니다.</p>
      </main>
    </>
  );
}
